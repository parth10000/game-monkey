var monkey,monkey_runing;
var backimagebackimagee;
var fruitgroup;
var fruit;
var stones;
var stonegroup;
var invisibleground;

function preload(){
monkey_runing=loadAnimation("monkey_01.png;monkey_01.png;monkey_01.png;monkey_01.png;monkey_01.png;monkey_01.png;monkey_01.png;monkey_01.png;monkey_01.png;monkey_01.png");
  backimagee=loadImage("jungle.png");
  bananagroup=loadImage("banana.png");
  obstaclegroup=loadImage("stone.png");
}

function setup() {
  createCanvas(400, 400); 
  
  monkey=createSprite(10,50,20,20);
  monkey.addAnimation(player_running);
  monkey.scale=0.5;
  
  backimage=(400,400,10,10);
  backimage.addImage(backimagee);
  backimage.x=backimage.width/2;
  backimage.velocityX=-2;
  
  invisibleground.visible=false;
}


  function draw() {
  background("white");
  drawSprites();
  stone();
  
  if(keyDown("space")){
   
    player.velocityY=-10;
  }  
if(  monkey.isTouching(fruitgroup)){
  fruitgroup.lifetime=0;
  fruitgroup.destroyEach();
}
  
    invisibleground.x = invisibleground.width/2;
    }
    monkey.collide(invisibleground);

stroke("white");
  textSize(20);
  fill("white");
 score(frameCount/frameRate);
  text("score"+score,100,50);

switch(score){
case 10:monkey.scale=0.12;
      break;
case 20:monkey.scale=0.14;
    break;
case 30:monkey.scale=0.16;
    break;
case 40:monkey.scale=0.18;
    break;
    default:break;
    
}
  
if(stonegroup.isTouching(monkey)){
monkey.scale=0.2;   
   }
  fruit(); 
//  stone();


function fruit(){
  if(frameCount%80==0){
    banana.addImage("Banana");
banana.scale=0.05;
banana.lifetime=150;
banana.velocityX=-2;
fruitgroup.add(banana);

   var rand = Math.round(random(120,200));
switch(rand){
  case 1:bnanana.addImage(banana);
    break;
    default:break;
    
}
    fruitgroup.add(banana);
}

function stone(){
   if(frameCount%100===0){
stones.velocityX=-6;
stones.addImage("Stone");
stones.scale=0.15;
stones.lifetime=100;
stonegroup.add(stones);                

     var rand = Math.round(random(120,200));
switch(rand){
  case 1:stones.addImage(stones);
    break;
    default:break;
   
    
}  
   }
}
}